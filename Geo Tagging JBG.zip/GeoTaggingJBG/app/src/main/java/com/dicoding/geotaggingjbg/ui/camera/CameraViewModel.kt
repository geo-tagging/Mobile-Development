package com.dicoding.geotaggingjbg.ui.camera

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.geotaggingjbg.data.Repository
import com.dicoding.geotaggingjbg.data.database.Entity
import java.io.File

class CameraViewModel(private val repository: Repository) : ViewModel() {

    //pindah ke save fragment
    suspend fun saveImageLocal(entity: Entity) = repository.saveImageToLocal(entity)
}