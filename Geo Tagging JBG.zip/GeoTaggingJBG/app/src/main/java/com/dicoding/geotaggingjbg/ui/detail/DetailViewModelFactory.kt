package com.dicoding.geotaggingjbg.ui.detail

class DetailViewModelFactory {
}