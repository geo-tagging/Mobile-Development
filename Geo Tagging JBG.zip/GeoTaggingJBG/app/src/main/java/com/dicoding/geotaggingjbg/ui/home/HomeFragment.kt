package com.dicoding.geotaggingjbg.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.geotaggingjbg.data.database.Entity
import com.dicoding.geotaggingjbg.databinding.FragmentHomeBinding
import com.dicoding.geotaggingjbg.ui.detail.DetailActivity

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val viewModel: HomeViewModel by viewModels {
        HomeViewModelFactory.getInstance(requireContext().applicationContext)
    }
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val layoutManager = LinearLayoutManager(requireContext())
        binding.rvData.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(requireContext(), layoutManager.orientation)
        binding.rvData.addItemDecoration(itemDecoration)
        //Manggil setViewData

//        viewModel.getData().observe(viewLifecycleOwner){data ->
//            if (userList.isEmpty()) {
//                binding.tvNone.visibility = View.VISIBLE
//            } else {
//                binding.tvNone.visibility = View.GONE
//            }
//        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun setViewData(userList: List<Entity>) {
        val adapter = HomeAdapter()
        adapter.submitList(userList)
        binding.rvData.adapter = adapter

        adapter.setOnItemClickCallback(object : HomeAdapter.OnItemClickCallback {
            override fun onItemClicked(data: Entity) {
                val intentToDetail = Intent(requireActivity(), DetailActivity::class.java)
                intentToDetail.putExtra("User", data.id)
                startActivity(intentToDetail)
            }
        })
    }
}