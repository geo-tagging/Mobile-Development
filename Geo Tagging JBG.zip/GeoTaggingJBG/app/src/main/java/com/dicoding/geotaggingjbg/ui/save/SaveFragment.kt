package com.dicoding.geotaggingjbg.ui.save

import android.content.Context
import android.graphics.Camera
import android.net.Uri
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.net.toUri
import androidx.fragment.app.DialogFragment
import com.dicoding.geotaggingjbg.R
import com.dicoding.geotaggingjbg.databinding.FragmentSaveBinding
import com.dicoding.geotaggingjbg.ui.camera.CameraFragment

class SaveFragment : Fragment() {

    private var _binding: FragmentSaveBinding? = null
    private val binding get() = _binding!!

    private var currentImageUri: Uri? = null
    private var optionDialogListener: OnOptionDialogListener? = null

    private lateinit var viewModel: SaveViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSaveBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (arguments != null) {
            currentImageUri = arguments?.getString(EXTRA_FILE)!!.toUri()
            binding.cvImagePreview.setImageURI(currentImageUri)
        }
        binding.btBatal.setOnClickListener{
            requireActivity().supportFragmentManager.popBackStack()
        }
        binding.btSimpan.setOnClickListener {
            val option = "Image Save"
            optionDialogListener?.onOptionChosen(option, currentImageUri.toString())
            requireActivity().supportFragmentManager.popBackStack()
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        val fragment = parentFragment

        if (fragment is CameraFragment) {
            this.optionDialogListener = fragment.optionDialogListener
        }
    }

//    override fun onDetach() {
//        super.onDetach()
//        this.optionDialogListener = null
//    }
    override fun onStart() {
        super.onStart()
        this.optionDialogListener = null
    }

    override fun onResume() {
        super.onResume()
        this.optionDialogListener = null
    }

    override fun onPause() {
        super.onPause()
        this.optionDialogListener = null
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    interface OnOptionDialogListener {
        fun onOptionChosen(text: String?, image: String?)
    }

    companion object {
        var EXTRA_FILE = "extra_file"
    }
}