package com.dicoding.geotaggingjbg.ui.save

import androidx.lifecycle.ViewModel

class SaveViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}